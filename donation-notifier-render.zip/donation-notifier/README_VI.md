# Donation Notifier — SePay → Discord

Ứng dụng Python/Flask nhận webhook giao dịch SePay và gửi thông báo vào Discord.

## 1. Đưa code lên GitHub
1. Tạo repository mới trên GitHub, ví dụ `donation-notifier`.
2. Upload các file trong thư mục này lên thư mục gốc của repository.
3. Không đưa API key hoặc Discord webhook URL vào code hay GitHub.

## 2. Deploy trên Render
1. Render Dashboard → New → Web Service.
2. Kết nối GitHub và chọn repository `donation-notifier`.
3. Render có thể tự nhận cấu hình từ `render.yaml`. Nếu phải điền thủ công:
   - Runtime: Python
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app`
   - Free plan (nếu tài khoản có lựa chọn này)
4. Trong Environment Variables, thêm:
   - `SEPAY_API_KEY` = API Key bạn tạo ở bước Security của webhook SePay
   - `DISCORD_WEBHOOK_URL` = URL webhook của kênh Discord log
5. Deploy và đợi trạng thái Live.

## 3. Cấu hình SePay
- Tên: `Donation Notifier`
- URL nhận webhook: `https://TEN-SERVICE.onrender.com/sepay` (thay bằng URL Render thật)
- Loại giao dịch: Tiền vào
- Định dạng: JSON
- Bảo mật: API Key
- API Key: dùng đúng cùng giá trị với biến `SEPAY_API_KEY` trên Render

SePay gửi header `Authorization: Apikey YOUR_API_KEY`; ứng dụng kiểm tra header này.

## 4. Kiểm tra
Mở `https://TEN-SERVICE.onrender.com/` — nếu online, sẽ hiện trạng thái JSON.
Sau đó dùng chức năng gửi thử của SePay và xem kênh Discord.

## Lưu ý quan trọng
- Không dùng chế độ SePay “không xác thực” cho giao dịch thật.
- Không chia sẻ API key hoặc URL Discord webhook. Nếu lộ, hãy thay mới.
- Render Free có thể ngủ khi không hoạt động, nên webhook đầu tiên sau thời gian nhàn rỗi có thể chậm và SePay có thể gửi lại.
- Chống giao dịch trùng trong bản này lưu trong RAM, nên có thể mất danh sách sau khi service khởi động lại. Với hệ thống quyên góp quan trọng, hãy thêm database bền vững và đối soát giao dịch.
- Nội dung chuyển khoản không chứng minh danh tính người gửi; bot chỉ thông báo giao dịch mà SePay báo về.
