import os
import time
import logging
from collections import OrderedDict

import requests
from flask import Flask, request, jsonify

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

SEPAY_API_KEY = os.environ.get("SEPAY_API_KEY", "").strip()
DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL", "").strip()

# In-memory duplicate protection. It resets if Render restarts the service.
SEEN_IDS = OrderedDict()
MAX_SEEN_IDS = 5000


def remember_transaction(transaction_id):
    if transaction_id in SEEN_IDS:
        return False
    SEEN_IDS[transaction_id] = time.time()
    while len(SEEN_IDS) > MAX_SEEN_IDS:
        SEEN_IDS.popitem(last=False)
    return True


def format_vnd(value):
    try:
        return f"{int(float(value)):,}".replace(",", ".") + " ₫"
    except (TypeError, ValueError):
        return "Không xác định"


@app.get("/")
def health():
    return jsonify({
        "service": "Donation Notifier",
        "status": "online",
        "webhook_path": "/sepay"
    }), 200


@app.post("/sepay")
def sepay_webhook():
    # Require API Key authentication; do not use unauthenticated mode in production.
    if not SEPAY_API_KEY:
        app.logger.error("SEPAY_API_KEY is not configured")
        return jsonify(success=False, message="Server not configured"), 500

    auth = request.headers.get("Authorization", "")
    expected = f"Apikey {SEPAY_API_KEY}"
    if not __import__("hmac").compare_digest(auth, expected):
        return jsonify(success=False, message="Unauthorized"), 401

    if not DISCORD_WEBHOOK_URL.startswith("https://discord.com/api/webhooks/") and not DISCORD_WEBHOOK_URL.startswith("https://discordapp.com/api/webhooks/"):
        app.logger.error("DISCORD_WEBHOOK_URL is missing or invalid")
        return jsonify(success=False, message="Discord webhook not configured"), 500

    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify(success=False, message="Expected JSON"), 400

    # Only announce incoming transfers.
    transfer_type = str(payload.get("transferType", "")).lower()
    if transfer_type not in ("in", "incoming"):
        return jsonify(success=True, message="Ignored non-incoming transaction"), 200

    transaction_id = str(payload.get("id", "")).strip()
    if not transaction_id:
        return jsonify(success=False, message="Missing transaction id"), 400

    if transaction_id in SEEN_IDS:
        return jsonify(success=True, message="Duplicate ignored"), 200

    amount = format_vnd(payload.get("transferAmount"))
    date = str(payload.get("transactionDate") or "Không có dữ liệu")
    content = str(payload.get("content") or payload.get("description") or "Không có nội dung")
    bank = str(payload.get("gateway") or "Ngân hàng")
    reference = str(payload.get("referenceCode") or "Không có")

    # No @everyone/@here/user mentions are allowed from bank-provided text.
    message = (
        "† **DONATION RECEIVED**\n"
        f"**Số tiền:** {amount}\n"
        f"**Ngân hàng:** {bank}\n"
        f"**Nội dung:** {content[:500]}\n"
        f"**Thời gian:** {date}\n"
        f"**Mã giao dịch:** `{transaction_id}`\n"
        f"**Mã tham chiếu:** `{reference[:150]}`\n"
        "\nCảm ơn bạn đã ủng hộ server."
    )

    try:
        response = requests.post(
            DISCORD_WEBHOOK_URL,
            json={
                "username": "Donation Notifier",
                "content": message,
                "allowed_mentions": {"parse": []}
            },
            timeout=10,
        )
        response.raise_for_status()
    except requests.RequestException:
        app.logger.exception("Failed to send donation message to Discord")
        return jsonify(success=False, message="Discord delivery failed"), 502

    remember_transaction(transaction_id)
    return jsonify(success=True), 200


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "10000"))
    app.run(host="0.0.0.0", port=port)
